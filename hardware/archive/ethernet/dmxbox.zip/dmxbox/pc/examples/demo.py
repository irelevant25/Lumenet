#!/usr/bin/env python3
"""Two small demos. Assumes RGB PARs at channels 1-3, 4-6, 7-9, 10-12.

  python demo.py 192.168.1.50 cues     # box-side fades: a few commands, smooth result
  python demo.py 192.168.1.50 stream   # PC-side effect: 40 Art-Net frames/second
"""
import math
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dmxbox import ArtNet, DmxBox  # noqa: E402

PARS = 4

def cues(host):
    looks = [
        ("warm",   [255, 120, 20]),
        ("ocean",  [0, 80, 255]),
        ("magenta", [255, 0, 180]),
    ]
    with DmxBox(host) as box:
        box.blackout(False)
        box.master(255)
        for name, rgb in looks:
            print("fading to", name)
            box.fade(1, rgb * PARS, seconds=3)
            time.sleep(4)
        # Chase: each PAR fades up while the previous one fades out.
        for step in range(PARS * 3):
            i = step % PARS
            frame = [0] * (PARS * 3)
            frame[i * 3:i * 3 + 3] = [255, 255, 255]
            box.fade(1, frame, seconds=0.4)
            time.sleep(0.5)
        box.fade(1, [0] * (PARS * 3), seconds=2)
        print(f"done ({box.retransmits} retransmits)")


def stream(host, seconds=15):
    art = ArtNet(host)
    t0 = time.monotonic()
    while (t := time.monotonic() - t0) < seconds:
        frame = []
        for p in range(PARS):  # rainbow rolling across the PARs
            h = (t * 0.2 + p / PARS) % 1.0
            frame += [int(127 + 127 * math.sin(2 * math.pi * (h + k / 3))) for k in range(3)]
        art.send(frame)
        time.sleep(1 / 40)
    art.send([0] * (PARS * 3))
    with DmxBox(host) as box:   # let the cue layer take over again
        box.release_artnet()


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[2] not in ("cues", "stream"):
        sys.exit(__doc__)
    {"cues": cues, "stream": stream}[sys.argv[2]](sys.argv[1])
