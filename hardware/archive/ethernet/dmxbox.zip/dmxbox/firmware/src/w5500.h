// Small, dependency-free W5500 driver: hardware TCP/IP chip used in UDP mode.
// (No WIZnet ioLibrary needed - the register map is simple enough.)
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "hardware/spi.h"

typedef struct {
    uint8_t mac[6];
    uint8_t ip[4];
    uint8_t netmask[4];
    uint8_t gateway[4];
} w5500_netcfg_t;

// Resets the chip, checks VERSIONR, applies network config and socket
// buffer sizes. Returns false if the chip doesn't answer (wiring!).
bool w5500_init(spi_inst_t *spi, uint pin_miso, uint pin_cs, uint pin_sck, uint pin_mosi,
                uint pin_rst, uint32_t baud, const w5500_netcfg_t *cfg);

bool w5500_link_up(void);

// Open socket `s` (0..7) as UDP on `port`. Broadcast reception stays enabled.
bool w5500_udp_open(uint8_t s, uint16_t port);
bool w5500_udp_is_open(uint8_t s);

// Receive one datagram. Returns its length, -1 if nothing is waiting,
// -2 if it was larger than `cap` (it is discarded).
int w5500_udp_recv(uint8_t s, uint8_t *buf, int cap, uint8_t ip[4], uint16_t *port);

bool w5500_udp_send(uint8_t s, const uint8_t ip[4], uint16_t port, const uint8_t *buf, int len);
