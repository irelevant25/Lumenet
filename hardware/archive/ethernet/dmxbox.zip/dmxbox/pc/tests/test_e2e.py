"""End-to-end tests: the Python client against the simulator, which runs the
same C engine/protocol code as the Pico firmware.

    cd sim && make && cd ../pc && python -m pytest -q tests
"""
import random
import socket
import struct
import subprocess
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "pc"))
from dmxbox import ArtNet, DmxBox, DmxBoxError, discover  # noqa: E402

SIM = ROOT / "sim" / "dmxbox_sim"


def _free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class Sim:
    def __init__(self, tmp_path, drop=0.0):
        self.art_port, self.ctl_port = _free_port(), _free_port()
        self.presets = tmp_path / "presets.bin"
        self.drop = drop
        self.proc = None

    def start(self):
        self.proc = subprocess.Popen(
            [str(SIM), "--artnet-port", str(self.art_port), "--ctrl-port", str(self.ctl_port),
             "--drop", str(self.drop), "--presets", str(self.presets), "--quiet"],
            stdout=subprocess.DEVNULL)
        time.sleep(0.15)
        return self

    def stop(self):
        self.proc.terminate()
        self.proc.wait()

    def box(self, **kw):
        return DmxBox("127.0.0.1", self.ctl_port, **kw)


@pytest.fixture
def sim(tmp_path):
    s = Sim(tmp_path).start()
    yield s
    s.stop()


@pytest.fixture
def lossy_sim(tmp_path):
    s = Sim(tmp_path, drop=0.3).start()
    yield s
    s.stop()


def test_ping(sim):
    info = sim.box().ping()
    assert info["firmware"] == "1.0" and info["channels"] == 512 and info["master"] == 255


def test_set_and_get(sim):
    box = sim.box()
    box.set(1, [255, 128, 7])
    box.set(512, [42])
    assert box.get_output(1, 4) == [255, 128, 7, 0]
    assert box.get_output(512, 1) == [42]


def test_fade_runs_on_the_box(sim):
    box = sim.box()
    box.fade(1, [200], seconds=0.6)
    time.sleep(0.3)
    mid = box.get_output(1, 1)[0]
    assert 60 < mid < 140, mid
    time.sleep(0.4)
    assert box.get_output(1, 1) == [200]


def test_fade_interrupt_starts_from_current_value(sim):
    box = sim.box()
    box.set(1, [255])
    box.fade(1, [0], seconds=1.0)
    time.sleep(0.5)
    box.fade(1, [255], seconds=1.0)          # reverse mid-fade: no jump
    v = box.get_output(1, 1)[0]
    assert 90 < v < 170, v


def test_master_and_blackout(sim):
    box = sim.box()
    box.set(1, [200, 100])
    box.master(128)
    assert box.get_output(1, 2) == [100, 50]
    box.blackout(True)
    assert box.get_output(1, 2) == [0, 0]
    assert box.ping()["blackout"]
    box.blackout(False)
    box.master(255)
    assert box.get_output(1, 2) == [200, 100]


def test_bad_arguments_are_rejected(sim):
    box = sim.box()
    with pytest.raises(DmxBoxError, match="BAD_ARG"):
        box.set(0, [1])
    with pytest.raises(DmxBoxError, match="BAD_ARG"):
        box.set(511, [1, 2, 3])
    with pytest.raises(DmxBoxError, match="EMPTY_SLOT"):
        box.preset_go(3)
    with pytest.raises(DmxBoxError, match="UNKNOWN_TYPE"):
        box.request(0x7E)


def test_presets_persist_across_restart(tmp_path):
    s = Sim(tmp_path).start()
    try:
        box = s.box()
        box.set(1, [10, 20, 30])
        box.preset_save(5)
        box.set(1, [0, 0, 0])
        box.preset_go(5)
        assert box.get_output(1, 3) == [10, 20, 30]
    finally:
        s.stop()
    s.start()                                # "power cycle"
    try:
        box = s.box()
        assert 5 in box.ping()["presets"]
        assert box.get_preset(5)[:4] == [10, 20, 30, 0]
        box.preset_go(5, seconds=0.2)
        time.sleep(0.3)
        assert box.get_output(1, 3) == [10, 20, 30]
        box.preset_clear(5)
        assert 5 not in box.ping()["presets"]
    finally:
        s.stop()


def _raw(box, msg_type, seq, payload):
    return struct.pack(">2sBBIHH", b"DX", 1, msg_type, box.session, seq, len(payload)) + payload


def test_retransmitted_request_is_not_executed_twice(sim):
    box = sim.box()
    box.set(1, [0])
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0.5)
    seq = (box.seq + 10) & 0xFFFF       # newer than anything the client used
    fade = _raw(box, 0x11, seq, struct.pack(">HHI", 1, 1, 1000) + bytes([250]))
    s.sendto(fade, ("127.0.0.1", sim.ctl_port))
    ack1 = s.recv(2048)
    time.sleep(0.6)
    s.sendto(fade, ("127.0.0.1", sim.ctl_port))   # duplicate: must NOT restart the fade
    ack2 = s.recv(2048)
    assert ack1 == ack2
    box.seq = seq                                 # keep the client's own seq ahead of ours
    time.sleep(0.5)
    assert box.get_output(1, 1) == [250]          # a restarted fade would be ~half way


def test_stale_request_is_dropped(sim):
    box = sim.box()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0.3)
    s.sendto(_raw(box, 0x10, 500, struct.pack(">HH", 1, 1) + b"\x11"), ("127.0.0.1", sim.ctl_port))
    s.recv(2048)
    s.sendto(_raw(box, 0x10, 499, struct.pack(">HH", 1, 1) + b"\x99"), ("127.0.0.1", sim.ctl_port))
    with pytest.raises(socket.timeout):
        s.recv(2048)
    box.seq = 500
    assert box.get_output(1, 1) == [0x11]


def test_reliable_over_lossy_network(lossy_sim):
    box = lossy_sim.box(timeout=0.05, retries=12)
    rng = random.Random(1)
    expected = [0] * 32
    for _ in range(60):
        ch = rng.randrange(1, 33)
        v = rng.randrange(256)
        box.set(ch, [v])
        expected[ch - 1] = v
    assert box.get_output(1, 32) == expected
    assert box.retransmits > 0                    # loss really happened...
    print(f"retransmits: {box.retransmits}")      # ...and was recovered


def test_artnet_htp_and_override(sim):
    box = sim.box()
    art = ArtNet("127.0.0.1", 0, sim.art_port)
    box.set(1, [100, 100])
    art.send([50, 200])
    time.sleep(0.05)
    assert box.get_output(1, 2) == [100, 200]     # HTP: highest wins
    assert box.ping()["artnet_live"]
    box.merge_mode("override")
    assert box.get_output(1, 2) == [50, 200]      # Art-Net replaces cue layer
    box.merge_mode("htp")
    box.release_artnet()
    assert box.get_output(1, 2) == [100, 100]


def test_artnet_other_universe_ignored(sim):
    box = sim.box()
    ArtNet("127.0.0.1", 3, sim.art_port).send([255])
    time.sleep(0.05)
    assert box.get_output(1, 1) == [0]


def test_discover(sim):
    nodes = discover(timeout=0.5, target="127.0.0.1", port=sim.art_port)
    assert len(nodes) == 1
    assert nodes[0]["short_name"] == "dmxbox" and nodes[0]["universe"] == 0
