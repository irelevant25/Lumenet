#include "w5500.h"
#include <string.h>
#include "hardware/gpio.h"
#include "pico/time.h"

// ---- SPI frame: [addr hi][addr lo][control] [data...]
// control = BSB[7:3] | RWB[2] | OM[1:0]  (OM = 00, variable length, CS framed)
#define BSB_COMMON  0x00
#define BSB_SREG(s) ((uint8_t)((s) * 4 + 1))
#define BSB_TX(s)   ((uint8_t)((s) * 4 + 2))
#define BSB_RX(s)   ((uint8_t)((s) * 4 + 3))
#define RWB_WRITE   0x04

// Common registers
#define MR        0x0000
#define GAR       0x0001
#define SUBR      0x0005
#define SHAR      0x0009
#define SIPR      0x000F
#define RTR       0x0019
#define RCR       0x001B
#define PHYCFGR   0x002E
#define VERSIONR  0x0039

// Socket registers
#define Sn_MR       0x0000
#define Sn_CR       0x0001
#define Sn_IR       0x0002
#define Sn_SR       0x0003
#define Sn_PORT     0x0004
#define Sn_DIPR     0x000C
#define Sn_DPORT    0x0010
#define Sn_RXBUF_SIZE 0x001E
#define Sn_TXBUF_SIZE 0x001F
#define Sn_TX_FSR   0x0020
#define Sn_TX_WR    0x0024
#define Sn_RX_RSR   0x0026
#define Sn_RX_RD    0x0028

#define Sn_MR_UDP     0x02
#define Sn_CR_OPEN    0x01
#define Sn_CR_CLOSE   0x10
#define Sn_CR_SEND    0x20
#define Sn_CR_RECV    0x40
#define Sn_IR_TIMEOUT 0x08
#define Sn_IR_SENDOK  0x10
#define SOCK_UDP      0x22

// Socket buffer plan (KB). RX total <= 16, TX total <= 16.
//   socket 0: Art-Net  - big RX so bursts of DMX packets don't get dropped
//   socket 1: control  - room for a few full GET_OUTPUT responses
static const uint8_t RX_KB[8] = {8, 4, 0, 0, 0, 0, 0, 0};
static const uint8_t TX_KB[8] = {2, 4, 0, 0, 0, 0, 0, 0};

static spi_inst_t *g_spi;
static uint g_cs;

static inline void cs(bool active) {
    asm volatile("nop \n nop \n nop");
    gpio_put(g_cs, !active);
    asm volatile("nop \n nop \n nop");
}

static void w5_read(uint16_t addr, uint8_t bsb, uint8_t *buf, size_t len) {
    uint8_t hdr[3] = {(uint8_t)(addr >> 8), (uint8_t)addr, (uint8_t)(bsb << 3)};
    cs(true);
    spi_write_blocking(g_spi, hdr, 3);
    spi_read_blocking(g_spi, 0x00, buf, len);
    cs(false);
}

static void w5_write(uint16_t addr, uint8_t bsb, const uint8_t *buf, size_t len) {
    uint8_t hdr[3] = {(uint8_t)(addr >> 8), (uint8_t)addr, (uint8_t)((bsb << 3) | RWB_WRITE)};
    cs(true);
    spi_write_blocking(g_spi, hdr, 3);
    spi_write_blocking(g_spi, buf, len);
    cs(false);
}

static uint8_t r8(uint16_t a, uint8_t bsb) { uint8_t v; w5_read(a, bsb, &v, 1); return v; }
static void w8(uint16_t a, uint8_t bsb, uint8_t v) { w5_write(a, bsb, &v, 1); }
static uint16_t r16(uint16_t a, uint8_t bsb) {
    uint8_t b[2]; w5_read(a, bsb, b, 2); return (uint16_t)((b[0] << 8) | b[1]);
}
static void w16(uint16_t a, uint8_t bsb, uint16_t v) {
    uint8_t b[2] = {(uint8_t)(v >> 8), (uint8_t)v}; w5_write(a, bsb, b, 2);
}
// RSR / FSR are updated by the chip while we read them: read until stable.
static uint16_t r16_stable(uint16_t a, uint8_t bsb) {
    uint16_t v1, v2 = r16(a, bsb);
    do { v1 = v2; v2 = r16(a, bsb); } while (v1 != v2);
    return v1;
}

static void sock_cmd(uint8_t s, uint8_t cmd) {
    w8(Sn_CR, BSB_SREG(s), cmd);
    while (r8(Sn_CR, BSB_SREG(s))) tight_loop_contents();  // chip clears CR when accepted
}

bool w5500_init(spi_inst_t *spi, uint pin_miso, uint pin_cs, uint pin_sck, uint pin_mosi,
                uint pin_rst, uint32_t baud, const w5500_netcfg_t *cfg) {
    g_spi = spi;
    g_cs = pin_cs;
    spi_init(spi, baud);
    spi_set_format(spi, 8, SPI_CPOL_0, SPI_CPHA_0, SPI_MSB_FIRST);
    gpio_set_function(pin_miso, GPIO_FUNC_SPI);
    gpio_set_function(pin_sck, GPIO_FUNC_SPI);
    gpio_set_function(pin_mosi, GPIO_FUNC_SPI);
    gpio_init(pin_cs);  gpio_set_dir(pin_cs, GPIO_OUT);  gpio_put(pin_cs, 1);
    gpio_init(pin_rst); gpio_set_dir(pin_rst, GPIO_OUT);

    gpio_put(pin_rst, 0);  sleep_ms(2);    // >= 500 us reset pulse
    gpio_put(pin_rst, 1);  sleep_ms(60);   // PLL lock + PHY start

    if (r8(VERSIONR, BSB_COMMON) != 0x04) return false;

    w8(MR, BSB_COMMON, 0x80);              // software reset
    absolute_time_t until = make_timeout_time_ms(100);
    while (r8(MR, BSB_COMMON) & 0x80)
        if (time_reached(until)) return false;

    w5_write(SHAR, BSB_COMMON, cfg->mac, 6);
    w5_write(GAR,  BSB_COMMON, cfg->gateway, 4);
    w5_write(SUBR, BSB_COMMON, cfg->netmask, 4);
    w5_write(SIPR, BSB_COMMON, cfg->ip, 4);
    // ARP/retransmit timeout: 100 ms x (3+1) tries, so a send to a vanished
    // host blocks at most ~400 ms instead of the default 1.8 s.
    w16(RTR, BSB_COMMON, 1000);
    w8(RCR, BSB_COMMON, 3);

    for (uint8_t s = 0; s < 8; s++) {
        w8(Sn_RXBUF_SIZE, BSB_SREG(s), RX_KB[s]);
        w8(Sn_TXBUF_SIZE, BSB_SREG(s), TX_KB[s]);
    }
    return true;
}

bool w5500_link_up(void) { return r8(PHYCFGR, BSB_COMMON) & 0x01; }

bool w5500_udp_open(uint8_t s, uint16_t port) {
    sock_cmd(s, Sn_CR_CLOSE);
    w8(Sn_IR, BSB_SREG(s), 0xFF);
    w8(Sn_MR, BSB_SREG(s), Sn_MR_UDP);
    w16(Sn_PORT, BSB_SREG(s), port);
    sock_cmd(s, Sn_CR_OPEN);
    return w5500_udp_is_open(s);
}

bool w5500_udp_is_open(uint8_t s) { return r8(Sn_SR, BSB_SREG(s)) == SOCK_UDP; }

int w5500_udp_recv(uint8_t s, uint8_t *buf, int cap, uint8_t ip[4], uint16_t *port) {
    if (r16_stable(Sn_RX_RSR, BSB_SREG(s)) == 0) return -1;

    // In UDP mode each datagram is prefixed by an 8-byte header:
    // peer IP (4), peer port (2), payload length (2). The chip wraps the
    // ring buffer address for us, so the pointer can be used as-is.
    uint16_t ptr = r16(Sn_RX_RD, BSB_SREG(s));
    uint8_t hdr[8];
    w5_read(ptr, BSB_RX(s), hdr, 8);
    ptr = (uint16_t)(ptr + 8);
    memcpy(ip, hdr, 4);
    *port = (uint16_t)((hdr[4] << 8) | hdr[5]);
    uint16_t len = (uint16_t)((hdr[6] << 8) | hdr[7]);

    int result = len;
    if (len > cap) result = -2;
    else if (len) w5_read(ptr, BSB_RX(s), buf, len);
    ptr = (uint16_t)(ptr + len);

    w16(Sn_RX_RD, BSB_SREG(s), ptr);
    sock_cmd(s, Sn_CR_RECV);
    return result;
}

bool w5500_udp_send(uint8_t s, const uint8_t ip[4], uint16_t port, const uint8_t *buf, int len) {
    if (len <= 0 || len > TX_KB[s] * 1024) return false;

    absolute_time_t until = make_timeout_time_ms(50);
    while (r16_stable(Sn_TX_FSR, BSB_SREG(s)) < len)
        if (time_reached(until)) return false;

    uint16_t ptr = r16(Sn_TX_WR, BSB_SREG(s));
    w5_write(ptr, BSB_TX(s), buf, (size_t)len);
    w16(Sn_TX_WR, BSB_SREG(s), (uint16_t)(ptr + len));
    w5_write(Sn_DIPR, BSB_SREG(s), ip, 4);
    w16(Sn_DPORT, BSB_SREG(s), port);
    sock_cmd(s, Sn_CR_SEND);

    // Wait until the chip has sent it (or ARP gave up), then clear the flag.
    uint8_t ir;
    do { ir = r8(Sn_IR, BSB_SREG(s)); } while (!(ir & (Sn_IR_SENDOK | Sn_IR_TIMEOUT)));
    w8(Sn_IR, BSB_SREG(s), ir & (Sn_IR_SENDOK | Sn_IR_TIMEOUT));
    return (ir & Sn_IR_SENDOK) != 0;
}
