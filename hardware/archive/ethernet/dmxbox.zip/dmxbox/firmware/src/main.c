// dmxbox firmware - Raspberry Pi Pico + W5500 -> DMX512
//
//   core 0: network (Art-Net + control protocol), buttons, LED, flash writes
//   core 1: engine render + DMX output, ~43 frames/s, nothing else
//
// The two cores share the engine under a critical section.
#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "pico/multicore.h"
#include "pico/critical_section.h"
#include "pico/flash.h"
#include "pico/unique_id.h"

#include "config.h"
#include "platform.h"
#include "engine.h"
#include "artnet.h"
#include "ctrl.h"
#include "storage.h"
#include "w5500.h"
#include "dmx_out.h"

#define SOCK_ARTNET 0
#define SOCK_CTRL   1

static engine_t           g_engine;
static preset_bank_t      g_bank;
static ctrl_t             g_ctrl;
static artnet_node_t      g_artnet;
static critical_section_t g_cs;
static uint8_t            g_frame[1 + DMX_CHANNELS];   // start code + channels

// ---------------------------------------------------------------- platform hooks
void plat_lock(void)   { critical_section_enter_blocking(&g_cs); }
void plat_unlock(void) { critical_section_exit(&g_cs); }
bool plat_save_presets(const preset_bank_t *b) { return storage_save(b); }

static inline uint32_t now_ms(void) { return to_ms_since_boot(get_absolute_time()); }

// ---------------------------------------------------------------- core 1: DMX
static void core1_main(void) {
    flash_safe_execute_core_init();   // lets core 0 pause us while writing flash
    dmx_out_init(pio0, PIN_DMX_TX, PIN_DMX_DE);
    g_frame[0] = 0x00;                // DMX512 null start code
    for (;;) {
        uint32_t now = now_ms();
        plat_lock();
        engine_render(&g_engine, now, g_frame + 1, true);
        plat_unlock();
        dmx_out_send(g_frame, sizeof g_frame);
    }
}

// ---------------------------------------------------------------- buttons
typedef struct { uint pin; bool stable, raw; uint32_t changed_ms; } button_t;

static void button_init(button_t *b, uint pin) {
    *b = (button_t){.pin = pin};
    gpio_init(pin);
    gpio_set_dir(pin, GPIO_IN);
    gpio_pull_up(pin);
}

// Returns true once per press (debounced, active low).
static bool button_pressed(button_t *b, uint32_t now) {
    bool raw = !gpio_get(b->pin);
    if (raw != b->raw) { b->raw = raw; b->changed_ms = now; }
    if (now - b->changed_ms >= 30 && raw != b->stable) {
        b->stable = raw;
        return raw;
    }
    return false;
}

// ---------------------------------------------------------------- network
static bool net_start(const w5500_netcfg_t *cfg) {
    if (!w5500_init(spi0, PIN_W5500_MISO, PIN_W5500_CS, PIN_W5500_SCK, PIN_W5500_MOSI,
                    PIN_W5500_RST, W5500_SPI_HZ, cfg))
        return false;
    return w5500_udp_open(SOCK_ARTNET, ARTNET_PORT) && w5500_udp_open(SOCK_CTRL, CTRL_PORT);
}

static uint8_t rxbuf[1024];
static uint8_t txbuf[CTRL_MAX_PKT];

// Drain up to `max` datagrams from one socket. Returns true if any arrived.
static bool service_socket(uint8_t sock, int max) {
    bool any = false;
    for (int i = 0; i < max; i++) {
        uint8_t ip[4];
        uint16_t port;
        int n = w5500_udp_recv(sock, rxbuf, sizeof rxbuf, ip, &port);
        if (n == -1) break;
        if (n < 0) continue;  // oversized, dropped
        any = true;
        int r = sock == SOCK_ARTNET
                    ? artnet_handle(&g_artnet, rxbuf, n, now_ms(), txbuf, sizeof txbuf)
                    : ctrl_handle(&g_ctrl, rxbuf, n, now_ms(), txbuf, sizeof txbuf);
        if (r > 0) w5500_udp_send(sock, ip, port, txbuf, r);
    }
    return any;
}

// ---------------------------------------------------------------- main
int main(void) {
    stdio_init_all();
    critical_section_init(&g_cs);

    gpio_init(PIN_LED);
    gpio_set_dir(PIN_LED, GPIO_OUT);
    gpio_init(PIN_DMX_DE);            // keep the line driver off until core 1 is ready
    gpio_set_dir(PIN_DMX_DE, GPIO_OUT);
    gpio_put(PIN_DMX_DE, 0);
    button_t btn_blackout, btn_preset;
    button_init(&btn_blackout, PIN_BTN_BLACKOUT);
    button_init(&btn_preset, PIN_BTN_PRESET);

    engine_init(&g_engine);
    storage_load(&g_bank);
    ctrl_init(&g_ctrl, &g_engine, &g_bank, now_ms());

    pico_unique_board_id_t uid;
    pico_get_unique_board_id(&uid);
    w5500_netcfg_t cfg = {
        .mac = {0x02, uid.id[3], uid.id[4], uid.id[5], uid.id[6], uid.id[7]},  // locally administered
        .ip = NET_IP, .netmask = NET_NETMASK, .gateway = NET_GATEWAY,
    };
    g_artnet = (artnet_node_t){.eng = &g_engine, .universe = ARTNET_UNIVERSE};
    memcpy(g_artnet.ip, cfg.ip, 4);
    memcpy(g_artnet.mac, cfg.mac, 6);

    multicore_launch_core1(core1_main);   // DMX runs from here on, network or not

    bool net_ok = net_start(&cfg);
    printf("dmxbox %d.%d  ip %d.%d.%d.%d  artnet universe %d  ctrl port %d  w5500 %s\n",
           FW_VERSION_MAJOR, FW_VERSION_MINOR, cfg.ip[0], cfg.ip[1], cfg.ip[2], cfg.ip[3],
           ARTNET_UNIVERSE, CTRL_PORT, net_ok ? "ok" : "NOT FOUND");

    uint32_t last_check = 0, last_rx = 0;
    bool link = false;

    for (;;) {
        uint32_t now = now_ms();

        if (net_ok) {
            if (service_socket(SOCK_ARTNET, 8)) last_rx = now;
            if (service_socket(SOCK_CTRL, 4))   last_rx = now;
        }

        if (now - last_check >= 1000) {
            last_check = now;
            if (!net_ok) {
                net_ok = net_start(&cfg);       // retry: module plugged in late?
                if (net_ok) printf("w5500 found\n");
            } else {
                bool l = w5500_link_up();
                if (l != link) printf("link %s\n", l ? "up" : "down");
                link = l;
                if (!w5500_udp_is_open(SOCK_ARTNET)) w5500_udp_open(SOCK_ARTNET, ARTNET_PORT);
                if (!w5500_udp_is_open(SOCK_CTRL))   w5500_udp_open(SOCK_CTRL, CTRL_PORT);
            }
        }

        if (button_pressed(&btn_blackout, now)) ctrl_toggle_blackout(&g_ctrl);
        if (button_pressed(&btn_preset, now))
            ctrl_preset_go(&g_ctrl, BUTTON_PRESET_SLOT, BUTTON_PRESET_FADE_MS, now);

        // LED: fast blink = no W5500, slow blink = no link, on = link,
        // flicker = packets arriving.
        bool led;
        if (!net_ok)      led = (now / 100) & 1;
        else if (!link)   led = (now / 500) & 1;
        else              led = (now - last_rx) > 40 || ((now / 40) & 1);
        gpio_put(PIN_LED, led);
    }
}
