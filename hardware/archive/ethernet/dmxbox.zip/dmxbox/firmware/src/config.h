// dmxbox - build-time configuration.
// Everything you are likely to change lives here.
#pragma once

#define FW_VERSION_MAJOR 1
#define FW_VERSION_MINOR 0

// ---------------------------------------------------------------- network
// Static IPv4 config. The PC must be in the same subnet.
#define NET_IP       {192, 168, 1, 50}
#define NET_NETMASK  {255, 255, 255, 0}
#define NET_GATEWAY  {192, 168, 1, 1}
// MAC is derived from the Pico's unique flash ID (locally administered 02:xx:..).

#define ARTNET_PORT    6454   // fixed by the Art-Net spec
#define CTRL_PORT      7000   // our own reliable command protocol
#define ARTNET_UNIVERSE   0   // 15-bit Port-Address this box listens to
#define NODE_SHORT_NAME "dmxbox"
#define NODE_LONG_NAME  "dmxbox - Pico + W5500 Art-Net node"

// In MERGE_ARTNET_OVERRIDE mode, Art-Net is "live" for this long after the
// last packet. After that the box falls back to the cue layer.
#define ARTNET_LIVE_MS 3000

// ---------------------------------------------------------------- DMX
#define DMX_CHANNELS 512       // slots sent per frame (24..512). Fewer = faster refresh.
// Break (176 us) and mark-after-break (12 us) are set in dmx_tx.pio.

// ---------------------------------------------------------------- presets
#define PRESET_SLOTS 16        // 16 x 512 bytes, stored in the last 12 KB of flash

// ---------------------------------------------------------------- pins (plain Pico)
#define PIN_DMX_TX     0       // -> RS-485 transceiver D (driver input)
#define PIN_DMX_DE     1       // -> RS-485 transceiver DE (driver enable), 10k pull-down
#define PIN_W5500_MISO 16      // SPI0 RX
#define PIN_W5500_CS   17
#define PIN_W5500_SCK  18      // SPI0 SCK
#define PIN_W5500_MOSI 19      // SPI0 TX
#define PIN_W5500_RST  20
#define PIN_BTN_BLACKOUT 14    // button to GND, toggles blackout
#define PIN_BTN_PRESET   15    // button to GND, fades to preset slot 0
#define PIN_LED          25    // on-board LED

#define W5500_SPI_HZ (20 * 1000 * 1000)  // 20 MHz is safe even with jumper wires
#define BUTTON_PRESET_SLOT 0
#define BUTTON_PRESET_FADE_MS 2000
