# dmxbox: Ethernet to DMX512 with a Raspberry Pi Pico

A small box with an **RJ45 Ethernet port** on one side and a **5-pin DMX output** on the other.
It is controlled from your own software over UDP:

* **Art-Net** (UDP 6454) is supported, so QLC+ and other lighting software work with it immediately.
* The **DX protocol** (UDP 7000) is a custom, reliable command protocol. It uses sequence numbers, ACKs,
  retransmits and duplicate detection. Fades run on the Pico, so they stay smooth even if the PC hiccups.

```
 PC ──Ethernet──► W5500 ──SPI──► Pico core 0: network, protocols, buttons, flash
                                 Pico core 1: fade engine ──► PIO + DMA ──► isolated RS-485 ──► XLR-5
```

| Folder | Contents |
|---|---|
| `firmware/` | Pico SDK project (C). Builds `dmxbox.uf2`. |
| `sim/` | The **same** engine and protocol C code, running on a PC over normal sockets. Use it to develop software before the hardware exists. |
| `pc/` | `dmxbox.py`: a Python library and CLI using only the standard library, plus demos and end-to-end tests. |

---

## 1. Hardware

### Bill of materials

| Part | Notes |
|---|---|
| Raspberry Pi Pico (RP2040) | Plain Pico; no Wi-Fi needed |
| W5500 Ethernet module | The common blue module with RJ45 and a 10-pin header. It is powered from 3.3 V. |
| **ISO1410** isolated RS-485 transceiver (TI) | Half-duplex. Logic side (VCC1) runs at 3.3 V, bus side (VCC2) at 3–5.5 V. ISO1430 or ADM2483 are alternatives. |
| Isolated DC-DC 5 V → 5 V, 1 W (e.g. B0505S) | Powers the bus side. Unregulated modules overshoot at light load, so add a **270 Ω dummy load** or use a regulated part. |
| SM712 TVS diode | ESD and surge protection on A/B, made for RS-485 |
| XLR-5 **female** panel jack | Standard for a DMX output |
| 10 kΩ resistor | Pull-down on DE, so the driver stays off during boot |
| 100 nF capacitors, 2× | Decoupling, one on each ISO1410 supply pin |
| 2 momentary buttons (optional) | Blackout and "preset 1" for use without a PC |
| Panel-mount RJ45 extension or keystone (optional) | So the cable doesn't plug straight into the module |

The parts cost roughly €20–30 plus an enclosure.

> **Bench-test shortcut:** a MAX3485 (3.3 V, not isolated) wired like the ISO1410 works fine for first
> tests. Use the isolated version for the real box. Lighting rigs produce ground loops and surges,
> and isolation keeps those out of the Pico. The laptop is already isolated by the Ethernet magnetics.

### Pin map (plain Pico)

| Pico pin | GPIO | Connects to |
|---|---|---|
| 21 | GP16 (SPI0 RX) | W5500 **MISO** |
| 22 | GP17 | W5500 **SCS** (chip select) |
| 24 | GP18 (SPI0 SCK) | W5500 **SCLK** |
| 25 | GP19 (SPI0 TX) | W5500 **MOSI** |
| 26 | GP20 | W5500 **RST** |
| 1 | GP0 | ISO1410 **D** (driver in) |
| 2 | GP1 | ISO1410 **DE** (driver enable), plus 10 kΩ to GND |
| 19 | GP14 | Button "blackout" to GND (optional) |
| 20 | GP15 | Button "preset 1" to GND (optional) |
| 36 | 3V3(OUT) | W5500 3.3 V, ISO1410 VCC1 |
| 39 | VSYS | Isolated DC-DC input (5 V) |
| 38 etc. | GND | W5500 GND, ISO1410 GND1, DC-DC input GND |

All pins can be changed in `firmware/src/config.h`. Wire the ISO1410 by **signal name** and check the
datasheet for pin numbers.

### Schematic (signal level)

```
                        LOGIC SIDE (Pico GND)          ║          BUS SIDE (isolated GND2)
                                                       ║
 Pico 3V3 ──┬── ISO1410 VCC1   (100n to GND1)          ║   ISO1410 VCC2 ──┬── DC-DC +5V out
            └── /RE  (receiver off: tie to VCC1)       ║   (100n to GND2) └── 270R ── GND2
 Pico GP0 ───── D                                      ║
 Pico GP1 ──┬── DE                                     ║   A ────────────────── XLR pin 3  (Data+)
          10k                                          ║   B ────────────────── XLR pin 2  (Data−)
 Pico GND ──┴── GND1                                   ║   GND2 ─────────────── XLR pin 1  (common/shield)
                                                       ║
 Pico VSYS ──── DC-DC +5V in                           ║   SM712: one line pin to A, the other to B,
 Pico GND ───── DC-DC GND in                           ║          common pin to GND2
                                                       ║   XLR pins 4, 5: not connected
```

Rules that matter:

* **A = Data+ = XLR pin 3, B = Data− = XLR pin 2.** Swapping these is the most common DMX build mistake.
* **Never connect GND2 to the Pico's GND.** That would defeat the isolation.
* **No 120 Ω terminator in the box.** The box is the start of the line. Terminate at the last fixture.
* For safety, keep the logic and bus sides physically apart on the board, about 4 mm or more of clearance.

### Power

* **Simplest:** USB into the Pico. It powers everything and you get log output over the same cable.
* **Built into a box:** use a 5 V DC jack → Schottky diode (e.g. 1N5819) → VSYS. The Pico datasheet recommends a diode
  when VBUS and an external supply can both be present.
* **Current:** W5500 about 130 mA and Pico about 25 mA, both from the Pico's 3.3 V regulator (300 mA max).
  The DMX side draws about 60–100 mA from 5 V when driving a terminated line.

---

## 2. Firmware

### Build

You need the Pico SDK 2.x and an ARM toolchain (`gcc-arm-none-eabi`). The VS Code Raspberry Pi Pico extension
installs both.

```bash
cd firmware
mkdir build && cd build
PICO_SDK_PATH=/path/to/pico-sdk cmake ..
make -j
```

This produces `build/dmxbox.uf2`.

### Flash

Hold **BOOTSEL** while plugging the Pico into USB. It mounts as a drive; copy `dmxbox.uf2` onto it.

### Configure

Edit `firmware/src/config.h`:

* IP address (default **192.168.1.50/24**)
* Art-Net universe (default 0)
* Number of channels sent per frame (default 512)
* Pins, and the button preset and fade time

### Check that it works

* **Serial log:** open the Pico's USB serial port (any terminal, 115200). It prints the IP, the Art-Net universe and whether the W5500 was found.
* **On-board LED:**

| LED | Meaning |
|---|---|
| fast blink (5 Hz) | W5500 not answering. Check the SPI wiring and 3.3 V. |
| slow blink (1 Hz) | No Ethernet link |
| on | Link up, idle |
| flicker | Packets arriving |

### How it works

* **`dmx_tx.pio`:** a 9-instruction PIO program. It generates the break (176 µs), the mark-after-break (12 µs)
  and 250 kbaud 8N2 bytes, with exact timing and no CPU involvement. DMA feeds it the 513-byte packet.
  A full universe refreshes at **43 Hz**. Lower `DMX_CHANNELS` for a faster refresh.
* **`w5500.c`:** a dependency-free W5500 driver of about 200 lines, using UDP sockets on the chip's
  hardware TCP/IP stack. No WIZnet ioLibrary is needed.
* **`engine.c`:** two layers, merged:
  * The **cue layer** is driven by the DX protocol and the buttons. Every channel has its own fade,
    computed in 16-bit at frame rate.
  * The **Art-Net layer** holds the last ArtDmx data.
  * `output = merge(cue, artnet) × master`, or 0 during blackout.
* **Merge modes:**
  * **HTP** (default): the highest value wins. The Art-Net look is *held* even if the PC goes to sleep,
    until you call `release-artnet`.
  * **Override:** Art-Net replaces the cue layer while packets keep arriving. After 3 s of silence, the
    cue layer takes over again.
* **Presets:** 16 snapshots of the current look, stored in the last 12 KB of flash with a CRC.
  They survive power cycles. While flash is being written, core 1 is paused safely (`flash_safe_execute`),
  and the DMX line just idles for about 150 ms, which the DMX standard allows.
* **Losing the network:** the box keeps outputting the last state. The buttons work without a PC:
  GP14 toggles blackout, and GP15 fades to preset slot 0 in 2 s.

> **Master and blackout scale every channel.** That is right for dimmers and RGB PARs. If you add
> moving heads, a blackout would also send pan/tilt to 0. In that case, add a channel mask in
> `engine_render()`.

---

## 3. PC side

### Network setup

Give the PC an address in the same subnet, e.g. **192.168.1.10/24**. A direct cable works; modern
network cards handle crossover automatically. A switch also works.

### Command line (`pc/dmxbox.py`, Python 3.8+, no dependencies)

```bash
export DMXBOX_HOST=192.168.1.50
python dmxbox.py discover                  # ArtPoll: lists every Art-Net node
python dmxbox.py ping
python dmxbox.py set 1 255 0 0             # ch1=255, ch2=0, ch3=0
python dmxbox.py fade 1 0 80 255 -t 3      # 3-second fade, computed on the box
python dmxbox.py preset save 0
python dmxbox.py preset go 0 -t 2
python dmxbox.py master 128
python dmxbox.py blackout on
python dmxbox.py get 1 12                  # what is on the DMX line right now
python dmxbox.py merge override            # or: htp
python dmxbox.py artnet 1 255 255          # one raw Art-Net frame
python dmxbox.py release-artnet
```

### Library

```python
from dmxbox import DmxBox, ArtNet

with DmxBox("192.168.1.50") as box:
    box.fade(1, [255, 120, 20] * 4, seconds=2.5)   # 4 RGB PARs at channels 1-12
    box.preset_save(3)
    print(box.ping())

art = ArtNet("192.168.1.50", universe=0)          # for effects computed on the PC
art.send(frame_of_512_values)                     # call ~40×/s
```

`pc/examples/demo.py` has a cue demo (box-side fades) and a streaming rainbow demo (Art-Net).

### QLC+ (or any Art-Net software)

Add an Art-Net output on the network adapter in the box's subnet, for universe 0 and IP 192.168.1.50.
`discover` (or QLC+'s own scan) should find a node called `dmxbox`.

### Simulator and tests

```bash
cd sim && make && ./dmxbox_sim --show 12           # prints channel values as they change
# another terminal:
python pc/dmxbox.py -H 127.0.0.1 fade 1 255 128 0 -t 2

cd pc && python -m pytest -q tests                 # 13 end-to-end tests
```

`./dmxbox_sim --drop 0.3` loses 30 % of control packets in each direction. Use it to test the reliability
layer; the test suite does exactly this.

---

## 4. The DX protocol (UDP 7000)

All integers are **big-endian**. Every message has a 12-byte header:

| Offset | Size | Field |
|---|---|---|
| 0 | 2 | magic `"DX"` |
| 2 | 1 | version = 1 |
| 3 | 1 | type |
| 4 | 4 | session ID: random per client; 0 = no duplicate detection |
| 8 | 2 | seq: +1 per new request |
| 10 | 2 | payload length |
| 12 | n | payload |

Every request gets an **ACK** (type `0x80`) back to the sender's IP and port. The ACK echoes the
request's session and seq, and its payload is `status u8` followed by data.

| Type | Name | Request payload | ACK data |
|---|---|---|---|
| 0x01 | PING | – | fw major, fw minor, flags, master, uptime_ms u32, preset mask u16, channels u16 |
| 0x10 | SET | start u16 (1-based), count u16, values[count] | – |
| 0x11 | FADE | start u16, count u16, duration_ms u32, values[count] | – |
| 0x20 | PRESET_SAVE | slot u8 | – |
| 0x21 | PRESET_GO | slot u8, duration_ms u32 | – |
| 0x22 | PRESET_CLEAR | slot u8 | – |
| 0x30 | MASTER | level u8 | – |
| 0x31 | BLACKOUT | 0/1 | – |
| 0x32 | RELEASE_ARTNET | – | – |
| 0x33 | MERGE_MODE | 0 = HTP, 1 = override | – |
| 0x40 | GET_OUTPUT | start u16, count u16 | values[count] |
| 0x41 | GET_PRESET | slot u8 | values[512] |

The PING flags byte: bit 0 = Art-Net live, bit 1 = blackout, bit 2 = override mode, bit 3 = Art-Net layer holding data.

Status codes: 0 OK, 1 BAD_LENGTH, 2 BAD_ARG, 3 UNKNOWN_TYPE, 4 STORAGE_ERROR, 5 EMPTY_SLOT.

### Reliability (TCP-ish, over UDP)

* **Client:** stop-and-wait. It sends a request and waits for the ACK with the same session and seq.
  If none arrives, it retransmits the identical packet with exponential back-off.
* **Box:** for each of the 8 most recent sessions, it remembers the last seq and the ACK it sent.
  * **Same seq again:** the request is a retransmit (the original or its ACK got lost). The box replays the
    cached ACK and does **not** execute the request again. Without this, a retransmitted FADE would restart
    the fade.
  * **Older seq:** the packet is stale and has been wandering the network. It is dropped silently.
  * **Newer seq:** the request is executed, and the ACK is cached.
* **Multiple threads or programs:** give each its own `DmxBox` instance (its own session).

---

## 5. Ideas for later

* **Your own network stack:** put the W5500 in MACRAW mode and write ARP, IPv4, UDP and ICMP yourself.
  `w5500.c` is the place to start.
* **A DHCP client** (UDP 67/68) instead of a static IP.
* **sACN / E1.31** (UDP 5568, multicast) alongside Art-Net.
* **A second universe:** a second PIO state machine plus a second transceiver; the code is ready for more SMs.
* **Pushed state:** a "subscribe" message, so the box sends live output to your UI.

## Verification status

* **Firmware:** builds without warnings against Pico SDK 2.1.1.
* **PIO program:** emulated cycle by cycle and decoded like a DMX receiver would. Break 177 µs,
  MAB 13 µs, all 513 slots correct in 8N2, 43 packets/s.
* **Engine, Art-Net and DX protocol:** pass 13 end-to-end tests via the simulator, including a run
  with 30 % packet loss in both directions.
* **Not yet tested on real hardware:** the W5500 driver and flash storage. Bring it up step by step:
  1. Check the LED and serial log.
  2. Run `ping`.
  3. Measure DMX with one fixture.
