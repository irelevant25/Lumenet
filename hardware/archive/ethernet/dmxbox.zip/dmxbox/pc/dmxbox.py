#!/usr/bin/env python3
"""dmxbox PC client - Python 3.8+, standard library only.

Two ways to talk to the box:

  DmxBox  - the reliable "DX" control protocol (UDP 7000): set / fade / presets /
            master / blackout. Every call waits for an ACK and retransmits on
            loss; the box executes each request exactly once.
  ArtNet  - plain Art-Net streaming (UDP 6454). Fire-and-forget; send the full
            universe ~30-44 times per second.

Library use:
    from dmxbox import DmxBox
    box = DmxBox("192.168.1.50")
    box.fade(1, [255, 120, 0], seconds=2.5)     # channels 1-3

Command line:
    python dmxbox.py -H 192.168.1.50 ping
    python dmxbox.py -H 192.168.1.50 fade 1 255 120 0 --time 2.5
    python dmxbox.py discover
"""
import argparse
import os
import random
import socket
import struct
import threading
import time

CTRL_PORT = 7000
ARTNET_PORT = 6454
CHANNELS = 512

_HDR = struct.Struct(">2sBBIHH")  # magic, version, type, session, seq, payload length

PING, SET, FADE = 0x01, 0x10, 0x11
PRESET_SAVE, PRESET_GO, PRESET_CLEAR = 0x20, 0x21, 0x22
MASTER, BLACKOUT, RELEASE_ARTNET, MERGE_MODE = 0x30, 0x31, 0x32, 0x33
GET_OUTPUT, GET_PRESET, ACK = 0x40, 0x41, 0x80

STATUS = {0: "OK", 1: "BAD_LENGTH", 2: "BAD_ARG", 3: "UNKNOWN_TYPE",
          4: "STORAGE_ERROR", 5: "EMPTY_SLOT"}


class DmxBoxError(Exception):
    """The box answered with an error status."""


class DmxBoxTimeout(DmxBoxError):
    """No ACK after all retransmits (box off, wrong IP, cable...)."""


def _values(values):
    data = bytes(values)
    if not data:
        raise ValueError("need at least one value")
    return data


class DmxBox:
    """Reliable control connection. Thread-safe: requests are serialized
    (stop-and-wait), which is what the box's duplicate detection expects."""

    def __init__(self, host, port=CTRL_PORT, timeout=0.15, retries=6):
        self.addr = (host, port)
        self.timeout = timeout
        self.retries = retries
        self.session = random.getrandbits(32) or 1   # 0 means "no dedupe" to the box
        self.seq = random.getrandbits(16)
        self.retransmits = 0
        self._lock = threading.Lock()
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def close(self):
        self._sock.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # ------------------------------------------------------------ transport
    def request(self, msg_type, payload=b""):
        """Send one request, wait for its ACK, return the ACK's data bytes."""
        with self._lock:
            self.seq = (self.seq + 1) & 0xFFFF
            pkt = _HDR.pack(b"DX", 1, msg_type, self.session, self.seq, len(payload)) + payload
            timeout = self.timeout
            for attempt in range(self.retries):
                if attempt:
                    self.retransmits += 1
                self._sock.sendto(pkt, self.addr)
                deadline = time.monotonic() + timeout
                while True:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    self._sock.settimeout(remaining)
                    try:
                        data, _ = self._sock.recvfrom(2048)
                    except socket.timeout:
                        break
                    if len(data) < _HDR.size + 1:
                        continue
                    magic, ver, typ, sess, seq, plen = _HDR.unpack_from(data)
                    if (magic, ver, typ, sess, seq) != (b"DX", 1, ACK, self.session, self.seq):
                        continue  # late ACK of an earlier retransmit, or garbage
                    status = data[_HDR.size]
                    if status:
                        raise DmxBoxError(STATUS.get(status, f"status {status}"))
                    return data[_HDR.size + 1:_HDR.size + plen]
                timeout = min(timeout * 2, 1.0)   # back off: flash writes take ~150 ms
            raise DmxBoxTimeout(f"no answer from {self.addr[0]}:{self.addr[1]}")

    # ------------------------------------------------------------ commands
    def ping(self):
        d = self.request(PING)
        flags = d[2]
        return {
            "firmware": f"{d[0]}.{d[1]}",
            "artnet_live": bool(flags & 1),
            "blackout": bool(flags & 2),
            "merge": "override" if flags & 4 else "htp",
            "artnet_holding": bool(flags & 8),
            "master": d[3],
            "uptime_s": struct.unpack_from(">I", d, 4)[0] / 1000,
            "presets": [i for i in range(16) if struct.unpack_from(">H", d, 8)[0] >> i & 1],
            "channels": struct.unpack_from(">H", d, 10)[0],
        }

    def set(self, start, values):
        """Snap channels start, start+1, ... (1-based) to values."""
        v = _values(values)
        self.request(SET, struct.pack(">HH", start, len(v)) + v)

    def fade(self, start, values, seconds):
        """Fade channels from wherever they are now to values. The box
        computes the fade itself, so it stays smooth whatever the PC does."""
        v = _values(values)
        self.request(FADE, struct.pack(">HHI", start, len(v), round(seconds * 1000)) + v)

    def preset_save(self, slot):
        """Store the current look (before master/blackout) in flash."""
        self.request(PRESET_SAVE, bytes([slot]))

    def preset_go(self, slot, seconds=0.0):
        self.request(PRESET_GO, struct.pack(">BI", slot, round(seconds * 1000)))

    def preset_clear(self, slot):
        self.request(PRESET_CLEAR, bytes([slot]))

    def get_preset(self, slot):
        return list(self.request(GET_PRESET, bytes([slot])))

    def master(self, level):
        self.request(MASTER, bytes([level]))

    def blackout(self, on=True):
        self.request(BLACKOUT, bytes([1 if on else 0]))

    def release_artnet(self):
        """Forget the last Art-Net look (it is otherwise held forever in HTP mode)."""
        self.request(RELEASE_ARTNET)

    def merge_mode(self, mode):
        """'htp' (highest wins) or 'override' (Art-Net wins while streaming)."""
        self.request(MERGE_MODE, bytes([{"htp": 0, "override": 1}[mode]]))

    def get_output(self, start=1, count=CHANNELS):
        """What is on the DMX line right now (after master/blackout)."""
        return list(self.request(GET_OUTPUT, struct.pack(">HH", start, count)))


class ArtNet:
    """Art-Net ArtDmx sender for one universe."""

    def __init__(self, host, universe=0, port=ARTNET_PORT):
        self.addr = (host, port)
        self.universe = universe
        self._seq = 0
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    def send(self, values):
        data = bytes(values)[:CHANNELS]
        if len(data) < 2:
            data = data.ljust(2, b"\0")
        if len(data) % 2:
            data += b"\0"                        # spec: even length
        self._seq = self._seq % 255 + 1          # 1..255, 0 = "not used"
        pkt = (b"Art-Net\0" + struct.pack("<H", 0x5000) + struct.pack(">H", 14)
               + bytes([self._seq, 0]) + struct.pack("<H", self.universe)
               + struct.pack(">H", len(data)) + data)
        self._sock.sendto(pkt, self.addr)

    def close(self):
        self._sock.close()


def discover(timeout=1.0, target="255.255.255.255", port=ARTNET_PORT):
    """Broadcast ArtPoll and collect ArtPollReplies. Works for any Art-Net node."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    poll = b"Art-Net\0" + struct.pack("<H", 0x2000) + struct.pack(">H", 14) + bytes([0, 0])
    s.sendto(poll, (target, port))
    found, deadline = [], time.monotonic() + timeout
    try:
        while (remaining := deadline - time.monotonic()) > 0:
            s.settimeout(remaining)
            try:
                d, (ip, _) = s.recvfrom(1024)
            except socket.timeout:
                break
            if len(d) < 207 or d[:8] != b"Art-Net\0" or struct.unpack_from("<H", d, 8)[0] != 0x2100:
                continue
            found.append({
                "ip": ".".join(map(str, d[10:14])),
                "short_name": d[26:44].split(b"\0")[0].decode(errors="replace"),
                "long_name": d[44:108].split(b"\0")[0].decode(errors="replace"),
                "universe": (d[18] << 8) | (d[19] << 4) | (d[190] & 0x0F),
                "firmware": f"{d[16]}.{d[17]}",
                "mac": ":".join(f"{b:02x}" for b in d[201:207]),
            })
    finally:
        s.close()
    return found


# ---------------------------------------------------------------- CLI
def _main():
    p = argparse.ArgumentParser(description="Control a dmxbox.")
    p.add_argument("-H", "--host", default=os.environ.get("DMXBOX_HOST", "192.168.1.50"))
    p.add_argument("--port", type=int, default=CTRL_PORT)
    p.add_argument("--artnet-port", type=int, default=ARTNET_PORT)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("ping")
    sub.add_parser("discover")
    for name in ("set", "fade", "artnet"):
        sp = sub.add_parser(name)
        sp.add_argument("start", type=int)
        sp.add_argument("values", type=int, nargs="+")
        if name == "fade":
            sp.add_argument("-t", "--time", type=float, default=1.0)
        if name == "artnet":
            sp.add_argument("-u", "--universe", type=int, default=0)
    sp = sub.add_parser("preset")
    sp.add_argument("action", choices=["save", "go", "clear", "show"])
    sp.add_argument("slot", type=int)
    sp.add_argument("-t", "--time", type=float, default=0.0)
    sub.add_parser("master").add_argument("level", type=int)
    sub.add_parser("blackout").add_argument("state", choices=["on", "off"])
    sub.add_parser("release-artnet")
    sub.add_parser("merge").add_argument("mode", choices=["htp", "override"])
    sp = sub.add_parser("get")
    sp.add_argument("start", type=int, nargs="?", default=1)
    sp.add_argument("count", type=int, nargs="?", default=16)
    a = p.parse_args()

    if a.cmd == "discover":
        nodes = discover(port=a.artnet_port)
        for n in nodes:
            print(f"{n['ip']:15}  {n['short_name']:18} universe {n['universe']}  fw {n['firmware']}  {n['mac']}")
        if not nodes:
            print("no Art-Net nodes answered")
        return
    if a.cmd == "artnet":
        frame = [0] * (a.start - 1) + a.values
        ArtNet(a.host, a.universe, a.artnet_port).send(frame)
        return

    with DmxBox(a.host, a.port) as box:
        if a.cmd == "ping":
            for k, v in box.ping().items():
                print(f"{k:15} {v}")
        elif a.cmd == "set":
            box.set(a.start, a.values)
        elif a.cmd == "fade":
            box.fade(a.start, a.values, a.time)
        elif a.cmd == "preset":
            if a.action == "save":
                box.preset_save(a.slot)
            elif a.action == "go":
                box.preset_go(a.slot, a.time)
            elif a.action == "clear":
                box.preset_clear(a.slot)
            else:
                v = box.get_preset(a.slot)
                last = max((i for i, x in enumerate(v) if x), default=-1)
                print(" ".join(f"{i + 1}:{x}" for i, x in enumerate(v[:last + 1])) or "all zero")
        elif a.cmd == "master":
            box.master(a.level)
        elif a.cmd == "blackout":
            box.blackout(a.state == "on")
        elif a.cmd == "release-artnet":
            box.release_artnet()
        elif a.cmd == "merge":
            box.merge_mode(a.mode)
        elif a.cmd == "get":
            print(" ".join(f"{a.start + i}:{v}" for i, v in enumerate(box.get_output(a.start, a.count))))
        if box.retransmits:
            print(f"({box.retransmits} retransmits)")


if __name__ == "__main__":
    try:
        _main()
    except DmxBoxError as e:
        raise SystemExit(f"error: {e}")
